#!/usr/bin/bash
PATH=$PATH:/opt


### Sys wide alias
alias randomtheme='theme.sh -r'
alias choosetheme='theme.sh -i2' 


function setwp {
    gsettings set org.cinnamon.desktop.background picture.uri "file:///$1"
}

